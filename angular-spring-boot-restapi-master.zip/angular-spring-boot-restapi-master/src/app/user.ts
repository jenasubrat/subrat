export interface User {

    userId: number;
    firstName: string;
    lastName: string;
    emailId: string;
    designation: string;
    address: string;
    dob: string;
    joinDate: string;
    contactNo: number;
    pincode: number;
}